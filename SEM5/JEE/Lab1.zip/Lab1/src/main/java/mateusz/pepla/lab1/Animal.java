package mateusz.pepla.lab1;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "Animals")
public class Animal implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
    @Column(name = "species")
    private String species;
    @Column(name = "weight")
    private Integer weight;
    public Integer getWeight() {
        return weight;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "id=" + id +
                ", species='" + species + '\'' +
                ", weight=" + weight +
                '}';
    }
}
