package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;

import java.util.LinkedList;
import java.util.Queue;

public class Airport extends BasicSimObj {

	double arrivalInterval; // okres pomiedzy kolejnymi przylotami
	double landingDuration; // czas trwania lądowania
	double departureInterval; // okres pomiędzy odlotami
	ArrivalEvent arrivalEvent;
	LandingEvent landingEvent;
	DepartureEvent departureEvent;
	MonitoredVar mvOnTheGround;
    MonitoredVar mvInTheAir;
    MonitoredVar mvRunwayFree;
	RNGenerator rng;

	Queue<Plane> inAirQueue = new LinkedList<>();
	Plane landingPlane = null;
	Queue<Plane> onGroundQueue = new LinkedList<>();

    MonitoredVar mvWaitingTimeInAir;
	MonitoredVar mvWaitingTimeOnGround;
	
	public Airport(double arrivalInterval, double departureInterval)
			throws SimControlException {

		this.arrivalInterval = arrivalInterval;
		this.landingDuration = landingDuration;
		this.departureInterval = departureInterval;
		arrivalEvent = new ArrivalEvent(this, arrivalInterval);
		mvOnTheGround = new MonitoredVar();
		mvInTheAir = new MonitoredVar(); 
		mvRunwayFree = new MonitoredVar();
		mvRunwayFree.setValue(1);

		mvInTheAir.setValue(0);
		mvOnTheGround.setValue(0);

		mvWaitingTimeInAir = new MonitoredVar();
		mvWaitingTimeOnGround = new MonitoredVar();

		rng=new RNGenerator();
	}

	@Override
	public boolean filter(IPublisher publisher, INotificationEvent event) {
		return false;
	}

	@Override
	public void reflect(IPublisher publisher, INotificationEvent event) {
	}

	public void printState() {
		int lp;
		if (landingPlane != null) { lp = 1; } else { lp = 0; }
		System.out.println(simTime() + "\tW powietrzu :\t" + inAirQueue.size()
				+ "\tW trakcie lądowania:\t" + lp + "\tNa płycie:\t" + onGroundQueue.size());
	}

}
