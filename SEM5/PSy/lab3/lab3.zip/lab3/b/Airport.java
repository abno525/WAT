package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;

import java.util.LinkedList;
import java.util.Queue;

public class Airport extends BasicSimObj {
	boolean runwayFree; // dostępność pasa lądowania
	double arrivalInterval; // okres pomiedzy kolejnymi przylotami
	double landingDuration; // czas trwania lądowania
	double departureInterval; // okres pomiędzy odlotami
	ArrivalEvent arrivalEvent;
	LandingEvent landingEvent;
	DepartureEvent departureEvent;
	MonitoredVar mvOnTheGround;
    MonitoredVar mvInTheAir;
    MonitoredVar mvRunwayFree;
	RNGenerator rng;

	RNGenerator generator = new RNGenerator();
	
	Queue<Plane> inAirQueue = new LinkedList<>();
	Queue<Plane> landingQueue = new LinkedList<>();
	Queue<Plane> onGroundQueue = new LinkedList<>();
	MonitoredVar mvWaitingTimeTotal;
    MonitoredVar mvWaitingTimeInAir;
	
	public Airport(double arrivalInterval, double landingDuration, double departureInterval)
			throws SimControlException {
		generator.setSeed(1234);
		this.runwayFree = true;
		this.arrivalInterval = arrivalInterval;
		this.landingDuration = landingDuration;
		this.departureInterval = departureInterval;
		arrivalEvent = new ArrivalEvent(this, arrivalInterval);
		mvOnTheGround = new MonitoredVar();
		mvInTheAir = new MonitoredVar(); 
		mvRunwayFree = new MonitoredVar();
		mvRunwayFree.setValue(1);

		mvInTheAir.setValue(0);
		mvOnTheGround.setValue(0);
		mvWaitingTimeTotal = new MonitoredVar();
		mvWaitingTimeInAir = new MonitoredVar();

		rng=new RNGenerator();
	}

	@Override
	public boolean filter(IPublisher publisher, INotificationEvent event) {
		return false;
	}

	@Override
	public void reflect(IPublisher publisher, INotificationEvent event) {
	}

}
