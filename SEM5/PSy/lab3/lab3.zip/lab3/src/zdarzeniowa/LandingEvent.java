package zdarzeniowa;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class LandingEvent extends BasicSimEvent<Airport, Object> {

	public LandingEvent(Airport airport, double delay) throws SimControlException {
		super(airport, delay);
	}

	@Override
	protected void stateChange() throws SimControlException {
		Airport airport = getSimObj();

		if (airport.landingPlane != null) {
			Plane landedPlane = airport.landingPlane;
			airport.landingPlane = null;
			airport.mvInTheAir.setValue(airport.inAirQueue.size());

			landedPlane.startWaiting(simTime());
			airport.onGroundQueue.add(landedPlane);
			airport.mvOnTheGround.setValue(airport.onGroundQueue.size());

			System.out.println(simTime() + " - Wylądował samolot. Na płycie aktualnie jest: " + airport.onGroundQueue.size()
					+ " a w powietrzu " + airport.inAirQueue.size() + " samolot(ów)");

			if (airport.onGroundQueue.size() == 1 && airport.departuringPlane == null) {
				airport.departuringPlane = airport.onGroundQueue.poll();
				airport.mvWaitingTimeOnGround.setValue(airport.departuringPlane.stopWaiting(simTime()));
				airport.departureEvent = new DepartureEvent(airport, airport.departureInterval);
			}

			if (!airport.inAirQueue.isEmpty()) {
				airport.landingPlane = airport.inAirQueue.poll();
				airport.mvWaitingTimeInAir.setValue(airport.landingPlane.stopWaiting((int) simTime()));
				airport.landingEvent = new LandingEvent(airport, airport.landingPlane.landingDuration);
				System.out.println(simTime() + " - Zaplanowano lądowanie");
			} else {
				airport.mvRunwayFree.setValue(1);
				System.out.println(simTime() + " - Zwolniono pas lądowania");
			}
		}
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	public Object getEventParams() {
		return null;
	}
}
