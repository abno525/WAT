package zdarzeniowa;

import dissimlab.random.RNGenerator;

public class Plane {

    int category;
    int landingDuration;
    double waitingTime;

    public Plane(double time) {
        RNGenerator generator = new RNGenerator();
        generator.setSeed(1234);
        category = generator.uniformInt(1, 4);
        waitingTime = time;

        switch (category) {
            case 1:
                do {
                    landingDuration = (int) Math.ceil(generator.normal(3,1));
                } while (landingDuration < 1);
                break;
            case 2:
                landingDuration = generator.uniformInt(1,4);
                break;
            case 3:
                landingDuration = 2;
                break;
            default:
                break;
                }
    }

    /**
     * Metoda ustawiająca rozpoczęcia czasu oczekiwania
     * @param waitingTime czas rozpoczęcia czekania
     */
    public void startWaiting(double waitingTime) {
        this.waitingTime = waitingTime;
    }

    /**
     * Metoda zatrzymująca czas oczekiwania
     * @param time czas zatrzymania czekania
     */
    public double stopWaiting(double time) {
        return time - waitingTime;
    }
}
