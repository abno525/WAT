package zdarzeniowa;

import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class ArrivalEvent extends BasicSimEvent<Airport, Object> {

	RNGenerator generator = new RNGenerator();

	public ArrivalEvent(Airport airport, double arrivalInterval) throws SimControlException {
		super(airport, arrivalInterval);
	}

	@Override
	protected void stateChange() throws SimControlException {
		Airport airport = getSimObj();

		airport.inAirQueue.add(new Plane(simTime()));
		airport.mvInTheAir.setValue(airport.inAirQueue.size());

		System.out.println(simTime() + " - Przybył samolot. Nad lotniskiem aktualnie jest: " + airport.inAirQueue.size() + " samolot(ów)");

		airport.arrivalEvent = new ArrivalEvent(airport, generator.exponential(airport.arrivalInterval));

		if (airport.landingPlane == null) {
			airport.mvRunwayFree.setValue(0);
			airport.landingPlane = airport.inAirQueue.poll();
			airport.mvWaitingTimeInAir.setValue(airport.landingPlane.stopWaiting(simTime()));
			airport.landingEvent = new LandingEvent(airport, airport.landingPlane.landingDuration);
			System.out.println(simTime() + " - Zaplanowano lądowanie");
		}
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	public Object getEventParams() {
		return null;
	}
}
