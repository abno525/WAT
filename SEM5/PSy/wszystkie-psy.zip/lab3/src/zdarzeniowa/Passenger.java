package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.simcore.BasicSimObj;

public class Passenger extends BasicSimObj {

    double arrivalTime;
    static int nr=0;
    int nextNr;
    public ServiceDesk serviceDesk;

    public Passenger(double arrivalTime, ServiceDesk serviceDesk) {
        this.arrivalTime = arrivalTime;
        this.serviceDesk = serviceDesk;
        this.nextNr = nr++;
    }

    public int getNextNr() {
        return nextNr;
    }

    public void setNextNr(int nextNr) {
        this.nextNr = nextNr++;
    }

    public void setArrivalTime(double arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public double getArrivalTime() {
        return arrivalTime;
    }

    @Override
    public void reflect(IPublisher iPublisher, INotificationEvent iNotificationEvent) {

    }

    @Override
    public boolean filter(IPublisher iPublisher, INotificationEvent iNotificationEvent) {
        return false;
    }
}
