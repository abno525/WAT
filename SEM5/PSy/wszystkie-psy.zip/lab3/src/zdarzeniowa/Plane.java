package zdarzeniowa;

import dissimlab.random.RNGenerator;

public class Plane {

    int category;
    double landingDuration;
    double waitingTime;
    int passengerCount;

    public Plane(double time) {
        RNGenerator generator = new RNGenerator();
        category = generator.uniformInt(1, 4);
        waitingTime = time;

        switch (category) {
            case 1:
                do {
                    landingDuration = generator.normal(3,1);
                    passengerCount = generator.uniformInt(2, 10);

                } while (landingDuration < 1);
                break;
            case 2:
                landingDuration = generator.uniform(1,4);
                passengerCount = generator.uniformInt(3, 8);
                break;
            case 3:
                landingDuration = 2;
                passengerCount = generator.uniformInt(5, 12);
                break;
            default:
                break;
        }
    }

    /**
     * Metoda ustawiająca rozpoczęcia czasu oczekiwania
     * @param waitingTime czas rozpoczęcia czekania
     */
    public void startWaiting(double waitingTime) {
        this.waitingTime = waitingTime;
    }

    /**
     * Metoda zatrzymująca czas oczekiwania
     * @param time czas zatrzymania czekania
     */
    public double stopWaiting(double time) {
        return time - waitingTime;
    }
}
