package zdarzeniowa;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class BreakEvent extends BasicSimEvent<Element, Object> {

        private final ServiceDesk serviceDesk;

        public BreakEvent(Element entity, double delay, ServiceDesk serviceDesk) throws SimControlException {
            super(entity, delay);
            this.serviceDesk = serviceDesk;
        }

        @Override
        public Object getEventParams() {
            return null;
        }

        @Override
        protected void onTermination() throws SimControlException {
        }

        @Override
        protected void stateChange() throws SimControlException {
            if (getSimObj().getState()) {

                if (!serviceDesk.isFree()) {
                    if (serviceDesk.endServiceEvent != null) {
                        serviceDesk.endServiceEvent.terminate();
                    }
                }

                getSimObj().setState(false);
                getSimObj().createFixEvent();
                System.out.println(simTimeFormatted() + ": uszkodzenie elementu nr "+getSimObj().nr);
            }
        }
}
