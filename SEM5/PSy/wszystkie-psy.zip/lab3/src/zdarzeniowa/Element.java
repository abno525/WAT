package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;

public class Element extends BasicSimObj {

    private double lambda;
    private double mi;
    private double sigma;
    private boolean state;
    int nr;
    public MonitoredVar mvState;
    private RNGenerator rng;
    Structure str;
    private FixEvent fixEvent;
    private BreakEvent breakEvent;
    private ServiceDesk serviceDesk;

    public Element(int nr, double lambda, double mi, double sigma, Structure str, ServiceDesk serviceDesk) throws SimControlException {
        this.nr = nr;
        this.lambda = lambda;
        this.mi = mi;
        this.sigma = sigma;
        this.str = str;
        rng = new RNGenerator();
        this.state = true;
        mvState = new MonitoredVar();
        mvState.setValue(1.0);
        this.serviceDesk = serviceDesk;
        createBreakEvent();
    }

    public void createBreakEvent() throws SimControlException {
        breakEvent = new BreakEvent(this, rng.exponential(lambda), serviceDesk);
    }

    public void createFixEvent() throws SimControlException {
        double time;
        do {
            time = rng.normal(mi, sigma);
        } while (time <= 0.0);
        fixEvent = new FixEvent(this, time, serviceDesk);
    }

    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
        if (state) {
            mvState.setValue(1.0);
        } else {
            mvState.setValue(0.0);
        }
        str.changeState(state, nr);
    }

    @Override
    public void reflect(IPublisher iPublisher, INotificationEvent iNotificationEvent) {

    }

    @Override
    public boolean filter(IPublisher iPublisher, INotificationEvent iNotificationEvent) {
        return false;
    }
}
