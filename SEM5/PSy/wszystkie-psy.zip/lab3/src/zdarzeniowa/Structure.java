package zdarzeniowa;

import dissimlab.monitors.MonitoredVar;
import dissimlab.simcore.SimControlException;

public class Structure {
    Element element1;
    Element element2;
    private boolean elem1State;
    private boolean elem2State;
    private boolean state = true;
    MonitoredVar mvState;

    private ServiceDesk serviceDesk;

    public Structure(double lambda1, double mi1, double sigma1, double lambda2, double mi2, double sigma2, ServiceDesk serviceDesk) throws SimControlException {
        element1 = new Element(1, lambda1, mi1, sigma1, this, serviceDesk);
        element2 = new Element(2, lambda2, mi2, sigma2, this, serviceDesk);
        mvState = new MonitoredVar();
        mvState.setValue(1.0);
        elem1State = true;
        elem2State = true;
        this.serviceDesk = serviceDesk;
    }

    public void changeState(boolean state, int nrElem) {
        switch (nrElem) {
            case 1:
                elem1State = state;
                break;
            case 2:
                elem2State = state;
                break;
            default:
        }

        if (elem1State && elem2State) {
            this.state = true;
            mvState.setValue(1.0);
        } else {
            this.state = false;
            mvState.setValue(0.0);
        }
    }

    public boolean getState() {
        return state;
    }
}
