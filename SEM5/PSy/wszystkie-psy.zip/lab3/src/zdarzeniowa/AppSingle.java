package zdarzeniowa;

import dissimlab.monitors.Diagram;
import dissimlab.monitors.Diagram.DiagramType;
import dissimlab.monitors.Statistics;
import dissimlab.simcore.SimControlException;
import dissimlab.simcore.SimManager;

import java.awt.*;

public class AppSingle {
	
	public static void main(String[] args) {
		try{
			SimManager simMgr = SimManager.getInstance();
			
			Airport airport = new Airport(1, 3);
			
			// Dwa sposoby planowanego końca symulacji
			simMgr.setEndSimTime(100);
			// lub
			//SimControlEvent stopEvent = new SimControlEvent(20.0, SimControlStatus.STOPSIMULATION);
		
			// Uruchomienie symulacji metodą "start"
			simMgr.startSimulation();

			Diagram d1 = new Diagram(DiagramType.TIME, "R-inTheAir G-onTheGround B-runwayFree");
			d1.add(airport.mvInTheAir, java.awt.Color.RED);
			d1.add(airport.mvOnTheGround, java.awt.Color.GREEN);
			d1.add(airport.mvRunwayFree, java.awt.Color.BLUE);
			d1.show();

			Diagram d2 = new Diagram(DiagramType.TIME, "Element state");
			d2.add(airport.serviceDesk.structure.mvState, Color.RED);
			d2.add(airport.serviceDesk.structure.element1.mvState, Color.BLUE);
			d2.add(airport.serviceDesk.structure.element2.mvState, Color.GREEN);
			d2.show();

			Diagram d3 = new Diagram(DiagramType.TIME, "Queue size");
			d3.add(airport.serviceDesk.mvQueueSize, Color.MAGENTA);
			d3.show();

			Diagram d4 = new Diagram(DiagramType.TIME, "Waiting time + Service time");
			d4.add(airport.serviceDesk.mvWaitingTime, Color.MAGENTA);
			d4.add(airport.serviceDesk.mvServiceTime, Color.BLUE);
			d4.show();

			System.out.println("Średni czas oczekiwania w powietrzu wynosił:\t" + Statistics.arithmeticMean(airport.mvWaitingTimeInAir));
			System.out.println("Średni czas oczekiwania na płycie wynosiła:  \t" + Statistics.arithmeticMean(airport.mvWaitingTimeOnGround));
			System.out.println("Łączny czas oczekiwania samolotu wynosił:\t\t" + (Statistics.arithmeticMean(airport.mvWaitingTimeInAir) + Statistics.arithmeticMean(airport.mvWaitingTimeOnGround)));
			System.out.println("Średni czas oczekiwania pasarzera wynosił:\t\t" + Statistics.arithmeticMean(airport.serviceDesk.mvWaitingTime));
			System.out.println("Sredni czas obsługi pasarzera wynosił:\t\t\t" + Statistics.arithmeticMean(airport.serviceDesk.mvServiceTime));
			System.out.println("Średnia długość kolejki wynosiła:\t\t\t\t" + Statistics.arithmeticMean(airport.serviceDesk.mvQueueSize));
		}
		catch (SimControlException e) {
			e.printStackTrace();
		}
	}

}
