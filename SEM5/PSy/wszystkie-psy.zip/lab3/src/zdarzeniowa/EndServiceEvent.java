package zdarzeniowa;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class EndServiceEvent extends BasicSimEvent<ServiceDesk, Passenger> {

    private ServiceDesk serviceDesk;
    private Passenger passenger;
    private double serviceTime;
    private double creationTime;

    public EndServiceEvent(ServiceDesk serviceDesk, double delay, Passenger passenger) throws SimControlException {
        super(serviceDesk, delay, passenger);
        this.serviceDesk = serviceDesk;
        this.creationTime = simTime();
        this.serviceTime = delay;
    }

    @Override
    protected void stateChange() throws SimControlException {

        //System.out.println(simTimeFormatted() + " : Okienko - koniec obsługi pasażera nr: " + eventParams.getNextNr());
        serviceDesk.setFree(true);
        serviceDesk.mvServiceTime.setValue(simTime() - serviceDesk.startServiceTime, simTime());
        System.out.println(simTimeFormatted() + " : Koniec obsługi pasażera. czas prawdziwy obsługi: " + (simTime() - serviceDesk.startServiceTime));

        // plan kolejnego lądowania
        if (serviceDesk.passengerCount() > 0) {
            serviceDesk.startServiceEvent = new StartServiceEvent(serviceDesk);
        }
    }

    @Override
    protected void onTermination() throws SimControlException {
        serviceDesk.remainingServiceTime = serviceTime - (simTime() - creationTime);
        serviceDesk.servicedPassenger = passenger;
    }

    @Override
    public Passenger getEventParams() {
        return null;
    }
}
