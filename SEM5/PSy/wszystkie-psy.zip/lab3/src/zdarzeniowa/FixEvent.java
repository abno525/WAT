package zdarzeniowa;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class FixEvent extends BasicSimEvent<Element, Object> {

    private final ServiceDesk serviceDesk;
    private final Element entity;

    public FixEvent(Element entity, double delay, ServiceDesk serviceDesk) throws SimControlException {
        super(entity, delay);
        this.serviceDesk = serviceDesk;
        this.entity = entity;
    }

    @Override
    protected void stateChange() throws SimControlException {
        if (!getSimObj().getState()) {
            getSimObj().setState(true);

            System.out.println(simTimeFormatted() + ": naprawa elementu nr " + entity.nr);
            getSimObj().createBreakEvent();

            if ( serviceDesk.structure.getState()) {
                if (!serviceDesk.isFree()) {
                    serviceDesk.endServiceEvent = new EndServiceEvent(serviceDesk, serviceDesk.remainingServiceTime, serviceDesk.servicedPassenger);
                } else if (serviceDesk.passengerCount() > 0) {
                    serviceDesk.startServiceEvent = new StartServiceEvent(serviceDesk);
                }
            }
        }
    }

    @Override
    public Object getEventParams() {
        return null;
    }

    @Override
    protected void onTermination() throws SimControlException {
    }

}
