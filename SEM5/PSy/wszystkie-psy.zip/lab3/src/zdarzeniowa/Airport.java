package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;

import java.util.LinkedList;
import java.util.Queue;

public class Airport extends BasicSimObj {
	double arrivalInterval; // okres pomiedzy kolejnymi przylotami
	double departureInterval; // okres pomiędzy odlotami
	ServiceDesk serviceDesk;
	ArrivalEvent arrivalEvent;
	LandingEvent landingEvent;
	DepartureEvent departureEvent;
	MonitoredVar mvOnTheGround, mvInTheAir, mvRunwayFree;
	RNGenerator rng;

	Queue<Plane> inAirQueue = new LinkedList<zdarzeniowa.Plane>();
	Plane landingPlane = null;
	Plane departuringPlane = null;
	Queue<Plane> onGroundQueue = new LinkedList<>();
	MonitoredVar mvWaitingTimeOnGround, mvWaitingTimeInAir;

	public Airport(double arrivalInterval, double departureInterval) throws SimControlException {

		serviceDesk = new ServiceDesk();
		this.arrivalInterval = arrivalInterval;
		this.departureInterval = departureInterval;
		arrivalEvent = new ArrivalEvent(this, arrivalInterval);
		mvOnTheGround = new MonitoredVar();
		mvInTheAir = new MonitoredVar(); 
		mvRunwayFree = new MonitoredVar();
		mvRunwayFree.setValue(1);
		mvInTheAir.setValue(0);
		mvOnTheGround.setValue(0);
		rng=new RNGenerator();

		mvWaitingTimeOnGround = new MonitoredVar();
		mvWaitingTimeInAir = new MonitoredVar();

	}


	@Override
	public boolean filter(IPublisher publisher, INotificationEvent event) {
		return false;
	}

	@Override
	public void reflect(IPublisher publisher, INotificationEvent event) {
	}

}
