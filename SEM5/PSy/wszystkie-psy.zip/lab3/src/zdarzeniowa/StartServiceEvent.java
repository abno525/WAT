package zdarzeniowa;

import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class StartServiceEvent extends BasicSimEvent<ServiceDesk, Passenger> {

    private ServiceDesk serviceDesk;
    private double serviceTime;

    private RNGenerator rnGenerator;

    public StartServiceEvent(ServiceDesk serviceDesk) throws SimControlException {
        super(serviceDesk);
        this.rnGenerator = new RNGenerator();
        this.serviceDesk = serviceDesk;
    }

    @Override
    protected void stateChange() throws SimControlException {

        if (serviceDesk.passengerCount() > 0) {
            serviceDesk.setFree(false);
            serviceDesk.servicedPassenger = serviceDesk.removePassenger();
            serviceDesk.startServiceTime = simTime();

            do {
                serviceTime = rnGenerator.exponential(2.0);
            } while (serviceTime <= 0.0);

            //serviceDesk.mvServiceTime.setValue(serviceTime);
            serviceDesk.mvWaitingTime.setValue(simTime() - serviceDesk.servicedPassenger.getArrivalTime(), simTime());
            serviceDesk.endServiceEvent = new EndServiceEvent(serviceDesk, serviceTime, serviceDesk.servicedPassenger);

            System.out.println(simTimeFormatted() + " : Początek obsługi pasażera nr: " + serviceDesk.servicedPassenger.getNextNr()
                    + " czas czekania w kolejce: " + (simTime() - serviceDesk.servicedPassenger.getArrivalTime()));
            System.out.println("\t\t Start obsługi: " + simTimeFormatted() + " czas obsługi: " + serviceTime);
        }
    }

    @Override
    protected void onTermination() throws SimControlException {
    }

    @Override
    public Passenger getEventParams() {
        return null;
    }
}
