package zdarzeniowa;

import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class ArrivalEvent extends BasicSimEvent<Airport, Object> {

	RNGenerator generator = new RNGenerator();

	public ArrivalEvent(Airport airport, double arrivalInterval) throws SimControlException {
		super(airport, arrivalInterval);
	}

	@Override
	protected void stateChange() throws SimControlException {
		Airport airport = getSimObj();

		airport.inAirQueue.add(new Plane(simTime()));
		airport.mvInTheAir.setValue(airport.inAirQueue.size());

		System.out.println(simTimeFormatted() + " - Przybył samolot. Nad lotniskiem aktualnie jest: " + airport.inAirQueue.size() + " samolot(ów)");

		airport.arrivalEvent = new ArrivalEvent(airport, (int) Math.ceil(generator.exponential(airport.arrivalInterval)));

		if (airport.landingPlane == null) {
			airport.mvRunwayFree.setValue(0);
			airport.landingPlane = airport.inAirQueue.poll();
			airport.mvWaitingTimeInAir.setValue(airport.landingPlane.stopWaiting((int) simTime()));
			airport.landingEvent = new LandingEvent(airport, airport.landingPlane.landingDuration);
			System.out.println((int) simTime() + " - Zaplanowano lądowanie" + "Następny samolot wyląduje o czasie: " + (simTime() + airport.landingPlane.landingDuration));
		}
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	public Object getEventParams() {
		return null;
	}
}
