package zdarzeniowa;

import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class LandingEvent extends BasicSimEvent<Airport, Object> {

	private RNGenerator generator;
	private Airport airport;

	public LandingEvent(Airport airport, double delay) throws SimControlException {
		super(airport, delay);
		generator = new RNGenerator();
	}

	@Override
	protected void stateChange() throws SimControlException {
		Airport airport = getSimObj();

		if (airport.landingPlane != null) {
			Plane landedPlane = airport.landingPlane;

			// dodawanie pasarzerów do okienka
			for (int i = 0; i < landedPlane.passengerCount; i++) {
				Passenger passenger = new Passenger(simTime(), airport.serviceDesk);
				airport.serviceDesk.addPassenger(passenger);
				System.out.println(simTimeFormatted() + ": Przybył pasażer nr " + passenger.getNextNr());

				// Aktywacja okienka
				if (airport.serviceDesk.passengerCount() == 1 && airport.serviceDesk.isFree() && airport.serviceDesk.structure.getState()) {
					System.out.println(simTimeFormatted() + ": Aktywacja okienka");
					airport.serviceDesk.startServiceEvent = new StartServiceEvent(airport.serviceDesk);
				}
			}

			airport.landingPlane = null;
			airport.mvInTheAir.setValue(airport.inAirQueue.size());

			landedPlane.startWaiting(simTime());
			airport.onGroundQueue.add(landedPlane);
			airport.mvOnTheGround.setValue(airport.onGroundQueue.size());

			System.out.println( simTimeFormatted() + " - Wylądował samolot. Na płycie aktualnie jest: " + airport.onGroundQueue.size()
					+ " a w powietrzu " + airport.inAirQueue.size() + " samolot(ów)");

			if (airport.onGroundQueue.size() == 1 && airport.departuringPlane == null) {
				System.out.println("\t\t Następny odlot o czasie: " + (simTime() + airport.departureInterval));
				airport.departuringPlane = airport.onGroundQueue.poll();
				airport.mvWaitingTimeOnGround.setValue(airport.departuringPlane.stopWaiting( simTime()));
				airport.departureEvent = new DepartureEvent(airport, airport.departureInterval);
			}

			if (!airport.inAirQueue.isEmpty()) {
				airport.landingPlane = airport.inAirQueue.poll();
				airport.mvWaitingTimeInAir.setValue(airport.landingPlane.stopWaiting(simTime()));
				airport.landingEvent = new LandingEvent(airport, airport.landingPlane.landingDuration);
				System.out.println( simTimeFormatted() + " - Zaplanowano lądowanie");
				System.out.println("\t\t Następny samolot wyląduje o czasie: " + (simTime() + airport.landingPlane.landingDuration));
			} else {
				airport.mvRunwayFree.setValue(1);
				System.out.println(simTime() + " - Zwolniono pas lądowania");
			}
		}
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	public Object getEventParams() {
		return null;
	}
}
