package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;

import java.util.LinkedList;

public class ServiceDesk extends BasicSimObj {
    
    private LinkedList<Passenger> passengerQueue = new LinkedList<>();
    public boolean free = true;
    public StartServiceEvent startServiceEvent;
    public EndServiceEvent endServiceEvent;
    public MonitoredVar mvServiceTime = new MonitoredVar();
    public MonitoredVar mvWaitingTime = new MonitoredVar();
    public MonitoredVar mvQueueSize = new MonitoredVar();
    public Structure structure;

    public Passenger servicedPassenger;
    public double remainingServiceTime;
    public double startServiceTime;

    public ServiceDesk() throws SimControlException {
        structure = new Structure(0.1, 6, 1, 0.1, 8, 0.2, this);
    }

    // Wstawienie pasażera do kolejki
    public void addPassenger(Passenger passenger) {
        passengerQueue.add(passenger);
        mvQueueSize.setValue(passengerQueue.size());
    }

    // Pobranie pasażera z kolejki
    public Passenger removePassenger() {
        Passenger passenger = passengerQueue.removeFirst();
        mvQueueSize.setValue(passengerQueue.size());
        return passenger;
    }

    public int passengerCount() {
        return passengerQueue.size();
    }

    @Override
    public void reflect(IPublisher iPublisher, INotificationEvent iNotificationEvent) {
    }

    @Override
    public boolean filter(IPublisher iPublisher, INotificationEvent iNotificationEvent) {
        return false;
    }

    public void setFree(boolean free) {
        this.free = free;
    }

    public boolean isFree() {
        return free;
    }


}
