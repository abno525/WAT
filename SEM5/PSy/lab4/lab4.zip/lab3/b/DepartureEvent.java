package zdarzeniowa;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class DepartureEvent extends BasicSimEvent<Airport, Object> {

	public DepartureEvent(Airport airport, double delay) throws SimControlException {
		super(airport, delay);
	}

	@Override
	protected void stateChange() throws SimControlException {
		Airport airport = getSimObj();

		if (!airport.onGroundQueue.isEmpty()) {
			airport.onGroundQueue.poll();
			airport.mvOnTheGround.setValue(airport.onGroundQueue.size());
			System.out.println(
					simTime() + " - Odleciał samolot. Na płycie aktualnie jest: " + airport.onGroundQueue.size() + " samolot(ów)");
			if (airport.onGroundQueue.size() > 1) {
				airport.departureEvent = new DepartureEvent(airport, airport.departureInterval);
			}
		}		
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	public Object getEventParams() {
		return null;
	}
}
