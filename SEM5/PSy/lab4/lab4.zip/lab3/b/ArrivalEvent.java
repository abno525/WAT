package zdarzeniowa;

import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class ArrivalEvent extends BasicSimEvent<Airport, Object> {

	RNGenerator generator = new RNGenerator();

	public ArrivalEvent(Airport airport, double delay) throws SimControlException {
		super(airport, delay);
	}

	@Override
	protected void stateChange() throws SimControlException {
		Airport airport = getSimObj();

		airport.inAirQueue.add(new Plane((int) simTime()));
		airport.mvInTheAir.setValue(airport.inAirQueue.size());

		System.out.println(simTime() + " - Przybył samolot. Nad lotniskiem aktualnie jest: "
				+ airport.inAirQueue.size() + " samolot(ów)");

		airport.arrivalEvent = new ArrivalEvent(airport, (int) Math.ceil(generator.exponential(airport.arrivalInterval)));
		if (airport.runwayFree) {
			airport.runwayFree = false;
			airport.mvRunwayFree.setValue(0);
			airport.landingQueue.add(airport.inAirQueue.poll());
			airport.landingQueue.peek().stopWaiting((int) simTime());
			airport.mvWaitingTimeInAir.setValue(airport.landingQueue.peek().getTotalWaitingTime());
			airport.landingEvent = new LandingEvent(airport, airport.landingDuration);
			System.out.println(simTime() + " - Zaplanowano lądowanie");
		}
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	public Object getEventParams() {
		return null;
	}
}
