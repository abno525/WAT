package zdarzeniowa;

import dissimlab.monitors.Diagram;
import dissimlab.monitors.Diagram.DiagramType;
import dissimlab.monitors.Statistics;
import dissimlab.simcore.SimControlException;
import dissimlab.simcore.SimManager;

import java.awt.*;

public class AppSingle {
	
	public static void main(String[] args) {
		try{
			SimManager simMgr = SimManager.getInstance();
			
			Airport airport = new Airport(1, 3);
			
			// Dwa sposoby planowanego końca symulacji
			simMgr.setEndSimTime(50);
			// lub
			//SimControlEvent stopEvent = new SimControlEvent(20.0, SimControlStatus.STOPSIMULATION);
		
			// Uruchomienie symulacji metodą "start"
			simMgr.startSimulation();

			Diagram d1 = new Diagram(DiagramType.TIME, "R-inTheAir G-onTheGround B-runwayFree");
			d1.add(airport.mvInTheAir, java.awt.Color.RED);
			d1.add(airport.mvOnTheGround, java.awt.Color.GREEN);
			d1.add(airport.mvRunwayFree, java.awt.Color.BLUE);
			d1.add(airport.serviceDesk.mvQueueSize, Color.MAGENTA);
			d1.show();

			System.out.println("Średni czas oczekiwania w powietrzu wynosił:\t" + Statistics.arithmeticMean(airport.mvWaitingTimeInAir));
			System.out.println("Średni czas oczekiwania na płycie wynosił:  \t" + Statistics.arithmeticMean(airport.mvWaitingTimeOnGround));
			System.out.println("Łączny czas oczekiwania wynosił:\t\t\t\t" + (Statistics.arithmeticMean(airport.mvWaitingTimeInAir) + Statistics.arithmeticMean(airport.mvWaitingTimeOnGround)));
			System.out.println("Średni czas oczekiwania pasarzera wynosił:\t\t" + Statistics.arithmeticMean(airport.serviceDesk.mvWaitingTime));
			System.out.println("Sredni czas obsługi pasarzera wynosił:\t\t" + Statistics.arithmeticMean(airport.serviceDesk.mvServiceTime));
		}
		catch (SimControlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
