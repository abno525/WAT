package zdarzeniowa;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.simcore.BasicSimObj;

import java.util.LinkedList;

public class ServiceDesk extends BasicSimObj {
    private LinkedList<Passenger> passengerQueue = new LinkedList<>();
    private boolean wolne = true;
    public boolean free = true;
    public StartServiceEvent startServiceEvent;
    public EndServiceEvent endServiceEvent;
    public MonitoredVar mvServiceTime = new MonitoredVar();
    public MonitoredVar mvWaitingTime = new MonitoredVar();
    public MonitoredVar mvQueueSize = new MonitoredVar();


    // Wstawienie pasażera do kolejki
    public int addPassenger(Passenger passenger) {
        passengerQueue.add(passenger);
        mvQueueSize.setValue(passengerQueue.size());
        return passengerQueue.size();
    }

    // Pobranie pasażera z kolejki
    public Passenger removePassenger() {
        Passenger passenger = (Passenger) passengerQueue.removeFirst();
        mvQueueSize.setValue(passengerQueue.size());
        return passenger;
    }

    public int passengerCount() {
        return passengerQueue.size();
    }

    public boolean isWolneOkienko() {
        return wolne;
    }

    public void setWolneOkienko(boolean wolne) {
        this.wolne = wolne;
    }

    @Override
    public void reflect(IPublisher iPublisher, INotificationEvent iNotificationEvent) {
    }

    @Override
    public boolean filter(IPublisher iPublisher, INotificationEvent iNotificationEvent) {
        return false;
    }

    public void setFree(boolean free) {
        this.free = free;
    }

    public boolean isFree() {
        return free;
    }
}
