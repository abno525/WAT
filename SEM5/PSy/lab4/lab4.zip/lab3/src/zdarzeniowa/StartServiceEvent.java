package zdarzeniowa;

import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class StartServiceEvent extends BasicSimEvent<ServiceDesk, Passenger> {

    private ServiceDesk serviceDesk;
    private RNGenerator rnGenerator;

    public StartServiceEvent(ServiceDesk serviceDesk) throws SimControlException {
        super(serviceDesk);
        this.serviceDesk = serviceDesk;
        this.rnGenerator = new RNGenerator();
    }

    @Override
    protected void stateChange() throws SimControlException {
        if (serviceDesk.passengerCount() > 0) {
            serviceDesk.setFree(false);
            Passenger passenger = serviceDesk.removePassenger();
            double serviceTime;
            do {
                serviceTime = rnGenerator.exponential(2.0);
            } while (serviceTime <= 0.0);

            serviceDesk.mvServiceTime.setValue(serviceTime);
            serviceDesk.mvWaitingTime.setValue(simTime() - passenger.getArrivalTime(), simTime());
            System.out.println(simTimeFormatted() + " : Początek obsługi pasażera nr: " + passenger.getNextNr());
            serviceDesk.endServiceEvent = new EndServiceEvent(serviceDesk, serviceTime, passenger);

        }

    }

    @Override
    protected void onTermination() throws SimControlException {

    }

    @Override
    public Passenger getEventParams() {
        return null;
    }
}
