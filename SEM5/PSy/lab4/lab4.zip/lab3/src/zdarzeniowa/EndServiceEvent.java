package zdarzeniowa;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.SimControlException;

public class EndServiceEvent extends BasicSimEvent<ServiceDesk, Passenger> {

    private ServiceDesk serviceDesk;

    public EndServiceEvent(ServiceDesk serviceDesk, double delay, Passenger passenger) throws SimControlException {
        super(serviceDesk, delay, passenger);
        this.serviceDesk = serviceDesk;
    }


    @Override
    protected void stateChange() throws SimControlException {
        System.out.println(simTimeFormatted() + " : Okienko - koniec obsługi pasażera nr: " + eventParams.getNextNr());
        serviceDesk.setFree(true);

        // plan kolejnego lądowania
        if (serviceDesk.passengerCount() > 0) {
            serviceDesk.startServiceEvent = new StartServiceEvent(serviceDesk);
        }
    }

    @Override
    protected void onTermination() throws SimControlException {}

    @Override
    public Passenger getEventParams() {
        return null;
    }
}
