package StrNiezawodn;

import dissimlab.monitors.MonitoredVar;
import dissimlab.simcore.SimControlException;
import dissimlab.simcore.SimManager;

public class Struktura {
	Element element1;
	Element element2;
	private boolean stan;
	private boolean stanElem1;
	private boolean stanElem2;
	MonitoredVar mvStan;
	int minLicznoscProby=13;
	SimManager simMgr = SimManager.getInstance();
	public Struktura(double lambda1, double mi1, double sigma1, double lambda2, double mi2, double sigma2)
			throws SimControlException {
		element1 = new Element(1, lambda1, mi1, sigma1, this);
		element2 = new Element(2, lambda2, mi2, sigma2, this);
		stanElem1 = true;
		stanElem2 = true;
		stan = true;
		mvStan = new MonitoredVar();
		mvStan.setValue(1.0);
	}

	public void zmianaStanu(boolean stan, int nrElem) {
		switch (nrElem) {
		case 1: {
			stanElem1 = stan;
			break;
		}
		case 2: {
			stanElem2 = stan;
			break;
		}
		default: {
		}
		}
		if (stanElem1 && stanElem2) {
			stan = true;
			mvStan.setValue(1.0);
		} else {
			stan = false;
			mvStan.setValue(0.0);
			
			if (mvStan.numberOfSamples()>=minLicznoscProby) 
				simMgr.stopSimulation();
		}
	}

}
