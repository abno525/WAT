package StrNiezawodn;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;
import dissimlab.simcore.SimEventBarrier;

public class ZdarzenieNaprawa extends BasicSimEvent<Element, Object> {

	public ZdarzenieNaprawa(Element entity, double delay) throws SimControlException {
		super(entity, delay);
	}

	@Override
	public Object getEventParams() {
		return null;
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	protected void stateChange() throws SimControlException {
		if (!getSimObj().isStan()) {
			getSimObj().setStan(true);		
			System.out.println(simTimeFormatted() + ": naprawa elementu nr "+getSimObj().nr);
			getSimObj().utworzZdarzenieUszkodzenie();
		}
	}

}
