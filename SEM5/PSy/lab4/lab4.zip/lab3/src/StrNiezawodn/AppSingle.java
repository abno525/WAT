package StrNiezawodn;

import dissimlab.monitors.Diagram;
import dissimlab.monitors.Diagram.DiagramType;
import dissimlab.simcore.SimControlException;
import dissimlab.simcore.SimManager;

public class AppSingle {
	
	public static void main(String[] args) {
		try{
			SimManager simMgr = SimManager.getInstance();
			
			//Struktura szeregowa 2 elementów
			Struktura str = new Struktura(0.1, 6.0, 1.0, 0.1, 8.0, 0.2);

			simMgr.setEndSimTime(50);
			simMgr.startSimulation();
			
			Diagram d = new Diagram(DiagramType.TIME, "Stan elementu");
			d.add(str.mvStan, java.awt.Color.RED);
			d.add(str.element1.getMvStan(), java.awt.Color.BLUE);
			d.add(str.element2.getMvStan(), java.awt.Color.GREEN);
			d.show();			
		}
		catch (SimControlException e) {
			e.printStackTrace();
		}
	}

}
