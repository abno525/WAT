package StrNiezawodn;

import dissimlab.simcore.BasicSimEvent;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;
import dissimlab.simcore.SimEventBarrier;

public class ZdarzenieUszkodzenie extends BasicSimEvent<Element, Object> {

	public ZdarzenieUszkodzenie(Element entity, double delay) throws SimControlException {
		super(entity, delay);
	}

	@Override
	public Object getEventParams() {
		return null;
	}

	@Override
	protected void onTermination() throws SimControlException {
	}

	@Override
	protected void stateChange() throws SimControlException {
		if (getSimObj().isStan()) {
			getSimObj().setStan(false);		
			System.out.println(simTimeFormatted() + ": uszkodzenie elementu nr "+getSimObj().nr);
			getSimObj().utworzZdarzenieNaprawa();
		}
	}
}
