package StrNiezawodn;

import dissimlab.broker.INotificationEvent;
import dissimlab.broker.IPublisher;
import dissimlab.monitors.MonitoredVar;
import dissimlab.random.RNGenerator;
import dissimlab.simcore.BasicSimObj;
import dissimlab.simcore.SimControlException;

public class Element extends BasicSimObj {
	private double lambda;
	private double mi;
	private double sigma;
	private boolean stan;
	int nr;
	private MonitoredVar mvStan;
	private RNGenerator rng;
	Struktura str;
	private ZdarzenieNaprawa zdarzenieNaprawa;
	private ZdarzenieUszkodzenie zdarzenieUszkodzenie;
	
	public Element(int nr, double lambda, double mi, double sigma, Struktura str) throws SimControlException {
		super();
		this.nr = nr;
		this.lambda = lambda; 
		this.mi = mi;
		this.sigma = sigma;
		this.str = str;
		rng = new RNGenerator();
		this.stan = true;
		mvStan = new MonitoredVar();
		mvStan.setValue(1.0);
		utworzZdarzenieUszkodzenie();		
	}
	
	public void utworzZdarzenieUszkodzenie() throws SimControlException {
		zdarzenieUszkodzenie = new ZdarzenieUszkodzenie(this, rng.exponential(lambda));		
	}
	
	public void utworzZdarzenieNaprawa() throws SimControlException {
		double czas;
		do {
			czas = rng.normal(mi, sigma);
		}while (czas <= 0.0);
		zdarzenieNaprawa = new ZdarzenieNaprawa(this, czas);		
	}
	
	public double getRngExponential() {
		return rng.exponential(lambda);
	}	

	public boolean isStan() {
		return stan;
	}

	public void setStan(boolean stan) {
		this.stan = stan;
		if (stan) {
			mvStan.setValue(1.0);
		}
		else {
			mvStan.setValue(0.0);
		}
		str.zmianaStanu(stan, nr);
	}

	public MonitoredVar getMvStan() {
		return mvStan;
	}
	
	@Override
	public boolean filter(IPublisher publisher, INotificationEvent event) {
		return false;
	}

	@Override
	public void reflect(IPublisher publisher, INotificationEvent event) {
	}

}
