﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace lab2
{
    public partial class Ostrzyzek : Page, IPostBackEventHandler
    {
        private static readonly string[] ImagePaths = { "/Images/car1.jpg", "/Images/car2.jpg", "/Images/car3.jpg", "/Images/car4.jpg" };
        private static readonly int[] Positions = { 2, 6, 8, 4 }; // Correct clockwise grid sequence
        private static int CurrentPositionIndex = 0; // Current image position
        private static DateTime StartTime; // Timer start time
        private static TimeSpan MinTime = TimeSpan.MaxValue;
        private static TimeSpan MaxTime = TimeSpan.Zero;

        // Local user statistics (reset each session)
        private static int localHoverCount = 0;
        private static int localSizeChangeCount = 0;

        private TimeSpan localMaxtime = TimeSpan.Zero;
        private TimeSpan localMintime = TimeSpan.MaxValue;


        public void RaisePostBackEvent(string eventArgument)
        {
            if (eventArgument == "AOImgCar")
            {
                HandleMouseHover();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ApplyCssClasses();
            AdjustImageSize();

            if (!IsPostBack)
            {
                StartTime = DateTime.Now;
                PopulateUserDropdown();

            }

            AOImgCar.Attributes["onmouseover"] = ClientScript.GetPostBackEventReference(this, "AOImgCar");
        }
        protected void AOBtnSwitch_Click(object sender, EventArgs e)
        {
            ResetTimes();

            // Store the current position and image
            int previousPositionIndex = CurrentPositionIndex;
            string previousImage = AOImgCar.ImageUrl;

            // Generate a random new position that is not the previous one
            do
            {
                CurrentPositionIndex = new Random().Next(Positions.Length);
            } while (CurrentPositionIndex == previousPositionIndex);

            // Generate a random new image that is not the same as the previous one
            string newImage;
            do
            {
                int randomImageIndex = new Random().Next(ImagePaths.Length);
                newImage = ImagePaths[randomImageIndex];
            } while (newImage == previousImage);

            // Set the new image
            AOImgCar.ImageUrl = newImage;

            // Move the image to the new random position
            var previousCell = FindControl($"AOCell{Positions[previousPositionIndex]}") as HtmlGenericControl;
            if (previousCell != null)
            {
                previousCell.Controls.Remove(AOImgCar);
            }

            var newCell = FindControl($"AOCell{Positions[CurrentPositionIndex]}") as HtmlGenericControl;
            if (newCell != null)
            {
                newCell.Controls.Add(AOImgCar);
            }

            // Ensure the size remains consistent
            AdjustImageSize();
        }


        protected void AORblSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            AdjustImageSize(); // Change the size based on the selected radio button
            ResetTimes(); // Reset the reaction timers

            // Explicitly keep the image in its current position
            var currentCell = FindControl($"AOCell{Positions[CurrentPositionIndex]}") as HtmlGenericControl;
            if (currentCell != null && !currentCell.Controls.Contains(AOImgCar))
            {
                currentCell.Controls.Add(AOImgCar); // Ensure the image remains in the current cell
            }

            localSizeChangeCount++;
            SizeChangesLabel.Text = localSizeChangeCount.ToString();

        }

        private void HandleMouseHover()
        {
            TimeSpan reactionTime = DateTime.Now - StartTime;

            if (reactionTime < MinTime)
                MinTime = reactionTime;

            if (reactionTime > MaxTime)
                MaxTime = reactionTime;

            AOLblMinTime.Text = MinTime.ToString(@"mm\:ss\.fff");
            AOLblMaxTime.Text = MaxTime.ToString(@"mm\:ss\.fff");

            StartTime = DateTime.Now;

            
            MoveImageClockwise();
            SetCarImage(CurrentPositionIndex);

            localHoverCount++;
            setCurrentUserPanel();
        }

        private void ApplyCssClasses()
        {
            AOGridContainer.Attributes["class"] = "grid-container";

            for (int i = 1; i <= 9; i++)
            {
                var cell = FindControl($"AOCell{i}") as HtmlGenericControl;
                if (cell != null)
                {
                    cell.Attributes["class"] = "grid-cell";
                }
            }

            foreach (int pos in Positions)
            {
                var borderedCell = FindControl($"AOCell{pos}") as HtmlGenericControl;
                if (borderedCell != null)
                {
                    borderedCell.Attributes["class"] = "grid-cell grid-cell-bordered";
                }
            }

            AOImgCar.CssClass = "car-image";
        }

        private void AdjustImageSize()
        {
            int size;

            switch (AORblSize.SelectedValue)
            {
                case "small":
                    size = 50;
                    break;
                case "medium":
                    size = 75;
                    break;
                case "large":
                default:
                    size = 100;
                    break;
            }

            AOImgCar.Width = size;
            AOImgCar.Height = size;
        }

        private void ResetTimes()
        {
            MinTime = TimeSpan.MaxValue;
            MaxTime = TimeSpan.Zero;
            AOLblMinTime.Text = "0:0,0";
            AOLblMaxTime.Text = "0:0,0";
            StartTime = DateTime.Now;
        }

        private void SetCarImage(int positionIndex)
        {
            string selectedImage = ImagePaths[positionIndex % ImagePaths.Length];
            AOImgCar.ImageUrl = selectedImage;

            AdjustImageSize(); 
        }

        private void MoveImageClockwise()
        {
            var currentCell = FindControl($"AOCell{Positions[CurrentPositionIndex]}") as HtmlGenericControl;
            if (currentCell != null)
            {
                currentCell.Controls.Remove(AOImgCar);
            }

            CurrentPositionIndex = (CurrentPositionIndex + 1) % Positions.Length;
            var newCell = FindControl($"AOCell{Positions[CurrentPositionIndex]}") as HtmlGenericControl;
            if (newCell != null)
            {
                newCell.Controls.Add(AOImgCar);
            }
        }


        protected void RegisterButton_Click(object sender, EventArgs e)
        {
            string fullName = AONameInput.Text.Trim();

            if (!Page.IsValid)  
            {
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["OstrzyzekDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string checkQuery = "SELECT COUNT(*) FROM Users WHERE Nazwa = @Nazwa";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Nazwa", fullName);
                    int userCount = (int)checkCmd.ExecuteScalar();

                    if (userCount > 0)
                    {

                        string activeCheckQuery = "SELECT Aktywny FROM Users WHERE Nazwa = @Nazwa";
                        using (SqlCommand activeCmd = new SqlCommand(activeCheckQuery, conn))
                        {
                            activeCmd.Parameters.AddWithValue("@Nazwa", fullName);

                            object result = activeCmd.ExecuteScalar();
                            int isActive = result != DBNull.Value ? Convert.ToInt32(result) : 0;

                            if (isActive == 1)
                            {
                                RegistrationError.Text = "Użytkownik jest już zalogowany!";
                                return;
                            }
                        }

                        string updateQuery = "UPDATE Users SET Aktywny = 1, IDSesji = @IDSesji WHERE Nazwa = @Nazwa";
                        using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                        {
                            string newSessionID = Guid.NewGuid().ToString();
                            cmd.Parameters.AddWithValue("@Nazwa", fullName);
                            cmd.Parameters.AddWithValue("@IDSesji", newSessionID);
                            cmd.ExecuteNonQuery();

                            Session["User"] = fullName;
                            Session["UserName"] = fullName;
                            Session["SessionID"] = newSessionID;
                        }
                    }
                    else
                    {
             
                        string insertQuery = @"
                    INSERT INTO Users (Nazwa, Data, Godzina, IleRozmiar, IlePolozenie, Aktywny, IDSesji, CzasMinimalny, CzasMaksymalny)
                    VALUES (@Nazwa, @Data, @Godzina, @IleRozmiar, @IlePolozenie, @Aktywny, @IDSesji, @CzasMinimalny, @CzasMaksymalny)";

                        using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                        {
                            string newSessionID = Guid.NewGuid().ToString();
                            cmd.Parameters.AddWithValue("@Nazwa", fullName);
                            cmd.Parameters.AddWithValue("@Data", DateTime.Now.ToString("yyyy-MM-dd"));
                            cmd.Parameters.AddWithValue("@Godzina", DateTime.Now.ToString("HH:mm:ss"));
                            cmd.Parameters.AddWithValue("@IleRozmiar", 0);
                            cmd.Parameters.AddWithValue("@IlePolozenie", 0);
                            cmd.Parameters.AddWithValue("@Aktywny", 1);
                            cmd.Parameters.AddWithValue("@IDSesji", newSessionID);
                            cmd.Parameters.AddWithValue("@CzasMinimalny", "0:0,000");
                            cmd.Parameters.AddWithValue("@CzasMaksymalny", "0:0,000 s");

                            cmd.ExecuteNonQuery();

                            Session["User"] = fullName;
                            Session["UserName"] = fullName;
                            Session["SessionID"] = newSessionID;
                        }


                    }

                    UserLabel.Text = fullName;
                    UserLabel.CssClass = "red-text";


                    using (SqlConnection conn1 = new SqlConnection(connectionString))
                    {
                        conn1.Open();
                        string query = "SELECT * FROM Users WHERE Nazwa = @Nazwa";

                        using (SqlCommand cmd = new SqlCommand(query, conn1))
                        {
                            cmd.Parameters.AddWithValue("@Nazwa", fullName);
                            SqlDataReader reader = cmd.ExecuteReader();

                            if (reader.Read())
                            {

                                StartDateLabel.Text = reader["Data"].ToString();
                                StartTimeLabel.Text = reader["Godzina"].ToString();
                                SizeChangesLabel.Text = reader["IleRozmiar"].ToString();
                                PositionChangesLabel.Text = reader["IlePolozenie"].ToString();
                                MinTimeServerLabel.Text = reader["CzasMinimalny"].ToString();
                                MaxTimeServerLabel.Text = reader["CzasMaksymalny"].ToString();

                                localHoverCount = int.Parse(PositionChangesLabel.Text);
                                localSizeChangeCount = int.Parse(SizeChangesLabel.Text); 

                            }
                        }
                    }

                }
            }

            if (string.IsNullOrEmpty(fullName)) return;

            RegistrationPanel.Visible = false;
            MainPanel.Visible = true;

            ResetTimes();
        }

        private void PopulateUserDropdown()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OstrzyzekDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Nazwa FROM Users WHERE Aktywny = 1 ORDER BY Nazwa";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    string selectedUser = DropDownList1.SelectedValue;

                    DropDownList1.Items.Clear();
                    while (reader.Read())
                    {
                        string userName = reader["Nazwa"].ToString();
                        DropDownList1.Items.Add(new ListItem(userName, userName));
                    }

                    if (DropDownList1.Items.FindByValue(selectedUser) != null)
                    {
                        DropDownList1.SelectedValue = selectedUser;
                    }
                }
            }
        }



        protected void UserDropdown_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedUser = DropDownList1.SelectedValue;

            if (string.IsNullOrEmpty(selectedUser))
                return;

            UpdateDatabasePanel();
        }




        protected void DropDownList1_PreRender(object sender, EventArgs e)
        {
            PopulateUserDropdown();
        }

        private void setCurrentUserPanel()
        {
            SizeChangesLabel.Text = localSizeChangeCount.ToString();

            PositionChangesLabel.Text = localHoverCount.ToString();

            if (MinTime < localMintime)
            {
                MinTimeServerLabel.Text = MinTime.ToString(@"m\:s\.fff");
                localMintime = MinTime;
            }

            if (MaxTime > localMaxtime)
            {
                MaxTimeServerLabel.Text = MaxTime.ToString(@"m\:s\.fff");
                localMaxtime = MaxTime;
            }
        }

        protected void AOZero_Data(object sender, EventArgs e)
        {
            SizeChangesLabel.Text = "0";
            PositionChangesLabel.Text = "0";
            MinTimeServerLabel.Text = "0:0,0 s";
            MaxTimeServerLabel.Text = "0:0,0 s";





            localHoverCount = 0;
            localSizeChangeCount = 0;
            MinTime = TimeSpan.MaxValue;
            MaxTime = TimeSpan.Zero;
        }

        public static string OnTimedEvent()
        {
            string result = "Action performed at: " + DateTime.Now.ToString();
            System.Diagnostics.Debug.WriteLine(result); 
            return result; 
        }

        public void AOUpdateData(object sender, EventArgs e)
        {
            string fullName = Session["UserName"] as string;

            if (string.IsNullOrEmpty(fullName))
            {
                System.Diagnostics.Debug.WriteLine("AOUpdateData Error: Session[UserName] is null or empty!");
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["OstrzyzekDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string updateQuery = @"
                    UPDATE Users 
                    SET IleRozmiar = @IleRozmiar, 
                        IlePolozenie = @IlePolozenie, 
                        CzasMinimalny = @CzasMinimalny, 
                        CzasMaksymalny = @CzasMaksymalny
                    WHERE Nazwa = @Nazwa";

                using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Nazwa", fullName);

                    int sizeChanges = int.TryParse(SizeChangesLabel.Text, out int parsedSize) ? parsedSize : 0;
                    int positionChanges = int.TryParse(PositionChangesLabel.Text, out int parsedPosition) ? parsedPosition : 0;

                    cmd.Parameters.AddWithValue("@IleRozmiar", sizeChanges);
                    cmd.Parameters.AddWithValue("@IlePolozenie", positionChanges);

                    string minTimeFormatted = MinTimeServerLabel.Text.Length > 15 ? MinTimeServerLabel.Text.Substring(0, 15) : MinTimeServerLabel.Text;
                    string maxTimeFormatted = MaxTimeServerLabel.Text.Length > 15 ? MaxTimeServerLabel.Text.Substring(0, 15) : MaxTimeServerLabel.Text;

                    cmd.Parameters.AddWithValue("@CzasMinimalny", minTimeFormatted);
                    cmd.Parameters.AddWithValue("@CzasMaksymalny", maxTimeFormatted);

                    cmd.ExecuteNonQuery();
                }
            }

            UpdateDatabasePanel();
        }

        private void UpdateDatabasePanel()
        {
            string selectedUser = DropDownList1.SelectedValue;
            if (string.IsNullOrEmpty(selectedUser)) return;

            string connectionString = ConfigurationManager.ConnectionStrings["OstrzyzekDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Users WHERE Nazwa = @Nazwa";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Nazwa", selectedUser);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        Label2.Text = reader["Data"].ToString();
                        Label3.Text = reader["Godzina"].ToString();
                        Label4.Text = reader["IleRozmiar"].ToString();
                        Label5.Text = reader["IlePolozenie"].ToString();
                        Label6.Text = reader["CzasMinimalny"].ToString();
                        Label7.Text = reader["CzasMaksymalny"].ToString();
                    }
                }
            }
        }
    }
}
