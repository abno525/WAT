﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Timers;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;

namespace lab2

{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
        ScriptManager.ScriptResourceMapping.AddDefinition("jquery", new ScriptResourceDefinition
        {
            Path = "~/Scripts/jquery-3.6.0.min.js", // Ensure this path exists in your project
            DebugPath = "~/Scripts/jquery-3.6.0.js",
            CdnPath = "https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js",
            CdnDebugPath = "https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.js",
            CdnSupportsSecureConnection = true,
            LoadSuccessExpression = "window.jQuery"


        });

        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["OstrzyzekDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE Users SET Aktywny = 0, IDSesji = ' '";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            System.IO.File.AppendAllText(HttpRuntime.AppDomainAppPath + "log.txt",
                $"{DateTime.Now}: Application started, all users set to inactive.\n");
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText(HttpRuntime.AppDomainAppPath + "error_log.txt",
                    $"{DateTime.Now}: Error in Application_Start: {ex.Message}\n");
            }


        }


        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {
                string username = Session["UserName"].ToString();
                string connectionString = ConfigurationManager.ConnectionStrings["OstrzyzekDB"].ConnectionString;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE Users SET Aktywny = 0, IDSesji = '' WHERE Nazwa = @Nazwa";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Nazwa", username);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

       
    }
}