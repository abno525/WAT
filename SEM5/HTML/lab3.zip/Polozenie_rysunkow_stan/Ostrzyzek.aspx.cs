﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Polozenie_rysunkow_stan
{
    public partial class Ostrzyzek : Page, IPostBackEventHandler
    {
        private static readonly string[] AOImagePaths = { "/Images/car1.jpg", "/Images/car2.jpg", "/Images/car3.jpg", "/Images/car4.jpg" };
        private static readonly int[] AOPositions = { 2, 6, 8, 4 };
        private static int AOCurrentPositionIndex = 0; 

        private static DateTime AOLocalStartTime;
        private static TimeSpan AOLocalMinTime = TimeSpan.MaxValue;
        private static TimeSpan AOLocalMaxTime = TimeSpan.Zero;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["User"] == null)
                {
                    RegistrationPanel.Visible = true;
                    MainPanel.Visible = false;

               
                    string username = Session["UserName"] as string;
                    if (!string.IsNullOrEmpty(username))
                    {
                        Global.RemoveUser(username); 
                    }
                }
                else
                {
                    RegistrationPanel.Visible = false;
                    MainPanel.Visible = true;

                    LoadUserData();
                    PopulateUserDropdown();
                    AOLocalStartTime = DateTime.Now;
                    SetCarImage(AOCurrentPositionIndex);
                }
            }

            AOImgCar.Attributes["onmouseover"] = ClientScript.GetPostBackEventReference(this, "AOImgCar");

            CheckAndUpdateTable();
            PopulateUserDropdown();
        }

        public void RaisePostBackEvent(string eventArgument)
        {
            if (eventArgument == "AOImgCar")
            {
                HandleMouseHover();
            }
        }

        protected void RegisterButton_Click(object sender, EventArgs e)
        {

            if (Page.IsValid) 
            {
                if (string.IsNullOrWhiteSpace(AONameInput.Text))
                {
                    RegistrationError.Text = "Nie wprowadzono żadnej wartości!";
                    return;
                }

                string AOusername = AONameInput.Text.Trim();
                var AOcurrentUser = new User(AOusername);
                Session["User"] = AOcurrentUser;
                Session["UserName"] = AOusername;

                Global.AddUser(AOcurrentUser);

                RegistrationPanel.Visible = false;
                MainPanel.Visible = true;

                LoadUserData();
                PopulateUserDropdown();
            }
        }

        private void LoadUserData()
        {
            string AOuserName = Session["UserName"] as string;

            UserLabel.Text = AOuserName;
            PopulateUserDropdown();

            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser != null)
            {
                UpdateTableForUser(AOcurrentUser);
            }
        }

        private void PopulateUserDropdown()
        {
            var AOusers = Global.GetUsers();

            UserDropdown.Items.Clear();
            foreach (var AOuser in AOusers)
            {
                UserDropdown.Items.Add(AOuser.AOUsername);
            }

            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser != null)
            {
                UserDropdown.SelectedValue = AOcurrentUser.AOUsername;
            }
        }

        private void CheckForDropdownUpdate()
        {
            var usersUpdated = HttpContext.Current.Application["UsersUpdated"] as bool?;

            if (usersUpdated == true)
            {
                PopulateUserDropdown();
                HttpContext.Current.Application["UsersUpdated"] = false; 
            }
        }

        protected void UserDropdown_SelectedIndexChanged(object sender, EventArgs e)
        {
            string AOselectedUsername = UserDropdown.SelectedValue;

            var AOusers = Global.GetUsers();
            var AOselectedUser = AOusers.Find(u => u.AOUsername == AOselectedUsername);

            if (AOselectedUser != null)
            {
                UpdateTableForUser(AOselectedUser);

                
                Session["User"] = AOselectedUser;
                Session["UserName"] = AOselectedUser.AOUsername;

               
                AdjustImageSize();

               
                SetCarImage(AOCurrentPositionIndex);
            }
        }

        private void UpdateTableForUser(User AOuser)
        {
            StartDateLabel.Text = AOuser.CreationDate.ToString("dd.MM.yyyy");
            StartTimeLabel.Text = AOuser.CreationTime.ToString("HH:mm");
            SizeChangesLabel.Text = AOuser.SizeChanges.ToString();
            PositionChangesLabel.Text = AOuser.PositionChanges.ToString();
            MinTimeServerLabel.Text = AOuser.MinTime == TimeSpan.MaxValue ? "0:0,000" : AOuser.MinTime.ToString(@"mm\:ss\.fff");
            MaxTimeServerLabel.Text = AOuser.MaxTime.ToString(@"mm\:ss\.fff");
        }

        private void DisplayServerData()
        {
            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser == null) return;

            UpdateTableForUser(AOcurrentUser);
        }

        protected void AOBtnSwitch_Click(object sender, EventArgs e)
        {
            ResetTimes();

           
            int AOpreviousPositionIndex = AOCurrentPositionIndex;
            string AOpreviousImage = AOImgCar.ImageUrl;

           
            do
            {
                AOCurrentPositionIndex = new Random().Next(AOPositions.Length);
            } while (AOCurrentPositionIndex == AOpreviousPositionIndex);

           
            string newImage;
            do
            {
                newImage = AOImagePaths[new Random().Next(AOImagePaths.Length)];
            } while (newImage == AOpreviousImage);

            AOImgCar.ImageUrl = newImage;

    
            SetCarImage(AOCurrentPositionIndex);

      
            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser != null)
            {
                AOcurrentUser.PositionChanges++;
            }
        }

        protected void AORblSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            AdjustImageSize(); 
            ResetTimes(); 

            var AOcurrentCell = FindControl($"AOCell{AOPositions[AOCurrentPositionIndex]}") as HtmlGenericControl;
            if (AOcurrentCell != null && !AOcurrentCell.Controls.Contains(AOImgCar))
            {
                AOcurrentCell.Controls.Add(AOImgCar); 
            }

            // Update AOuser stats
            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser != null)
            {
                AOcurrentUser.SizeChanges++;
            }
        }

        private void HandleMouseHover()
        {
            TimeSpan AOreactionTime = DateTime.Now - AOLocalStartTime;

   
            if (AOreactionTime < AOLocalMinTime)
            {
                AOLocalMinTime = AOreactionTime;
            }

            if (AOreactionTime > AOLocalMaxTime)
            {
                AOLocalMaxTime = AOreactionTime;
            }


            AOLblMinTime.Text = AOLocalMinTime.ToString(@"mm\:ss\.fff");
            AOLblMaxTime.Text = AOLocalMaxTime.ToString(@"mm\:ss\.fff");

            AOLocalStartTime = DateTime.Now;

          
            MoveImageClockwise();
            SetCarImage(AOCurrentPositionIndex); 

            // Update AOuser stats
            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser != null)
            {
                AOcurrentUser.PositionChanges++;
            }
        }

        private void MoveImageClockwise()
        {
            var AOcurrentCell = FindControl($"AOCell{AOPositions[AOCurrentPositionIndex]}") as HtmlGenericControl;
            if (AOcurrentCell != null)
            {
                AOcurrentCell.Controls.Remove(AOImgCar);
            }

            AOCurrentPositionIndex = (AOCurrentPositionIndex + 1) % AOPositions.Length;

            var AOnewCell = FindControl($"AOCell{AOPositions[AOCurrentPositionIndex]}") as HtmlGenericControl;
            if (AOnewCell != null)
            {
                AOnewCell.Controls.Add(AOImgCar);
            }
        }

        private void ResetTimes()
        {
            AOLocalMinTime = TimeSpan.MaxValue;
            AOLocalMaxTime = TimeSpan.Zero;

            AOLblMinTime.Text = "0:0,0 s";
            AOLblMaxTime.Text = "0:0,0 s";

            AOLocalStartTime = DateTime.Now;
        }

        private void AdjustImageSize()
        {
            int size;

            switch (AORblSize.SelectedValue)
            {
                case "small":
                    size = 50;
                    break;
                case "medium":
                    size = 75;
                    break;
                case "large":
                default:
                    size = 100;
                    break;
            }

            AOImgCar.Width = size;
            AOImgCar.Height = size;
        }

        private void SetCarImage(int AOpositionIndex)
        {
        
            AOImgCar.ImageUrl = AOImagePaths[AOpositionIndex % AOImagePaths.Length];

            
            var AOtargetCell = FindControl($"AOCell{AOPositions[AOpositionIndex]}") as HtmlGenericControl;
            if (AOtargetCell != null)
            {
                
                foreach (var AOposition in AOPositions)
                {
                    var cell = FindControl($"AOCell{AOposition}") as HtmlGenericControl;
                    if (cell != null && cell.Controls.Contains(AOImgCar))
                    {
                        cell.Controls.Remove(AOImgCar);
                    }
                }

                AOtargetCell.Controls.Add(AOImgCar);
            }

            AdjustImageSize();
        }

        private void CheckAndUpdateTable()
        {
            var AOcurrentUser = Session["User"] as User;
            if (AOcurrentUser == null) return;

            if ((DateTime.Now - AOcurrentUser.LastUpdateTime).TotalSeconds >= 10)
            {
                if (AOLocalMinTime < AOcurrentUser.MinTime && AOLocalMinTime != TimeSpan.MaxValue)
                {
                    AOcurrentUser.MinTime = AOLocalMinTime;
                }

                if (AOLocalMaxTime > AOcurrentUser.MaxTime)
                {
                    AOcurrentUser.MaxTime = AOLocalMaxTime;
                }

                AOcurrentUser.LastUpdateTime = DateTime.Now;

                PopulateUserDropdown(); 
                DisplayServerData(); 
            }
        }

        protected void ValidateUniqueUsername(object source, ServerValidateEventArgs args)
        {
            string AOusername = args.Value.Trim();

            var AOusers = Global.GetUsers();
            if (AOusers != null && AOusers.Exists(u => u.AOUsername.Equals(AOusername, StringComparison.OrdinalIgnoreCase)))
            {
                args.IsValid = false; 
            }
            else
            {
                args.IsValid = true; 
            }
        }


    }
}
