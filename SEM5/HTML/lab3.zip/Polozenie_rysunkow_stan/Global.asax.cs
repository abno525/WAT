﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace Polozenie_rysunkow_stan
{
    public class Global : HttpApplication
    {
        private static readonly object AOUserLock = new object(); // Lock object for thread safety

        protected void Application_Start(object sender, EventArgs e)
        {
            // Initialize the shared list of users
            Application["Users"] = new List<User>();
        }

        public static List<User> GetUsers()
        {
            // Safely access the users list
            lock (AOUserLock)
            {
                return HttpContext.Current?.Application["Users"] as List<User> ?? new List<User>();
            }
        }

        public static void AddUser(User AOuser)
        {
            lock (AOUserLock)
            {
                var users = GetUsers();
                if (users != null && !users.Exists(u => u.AOUsername == AOuser.AOUsername))
                {
                    users.Add(AOuser);
                }
            }
        }

        public static void RemoveUser(string AOusername)
        {
            lock (AOUserLock)
            {
                var users = GetUsers();
                if (users != null)
                {
                    users.RemoveAll(u => u.AOUsername == AOusername);
                }
            }
        }

        protected void Session_End(object sender, EventArgs e)
        {
            // Remove the AOuser from the global list when the session ends
            string AOusername = Session["UserName"] as string; // Retrieve the AOusername from the session
            if (!string.IsNullOrEmpty(AOusername))
            {
                Global.RemoveUser(AOusername); // Remove the AOuser from the global list
            }
        }
    }
}
