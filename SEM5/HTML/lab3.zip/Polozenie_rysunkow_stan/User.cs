﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System;

namespace Polozenie_rysunkow_stan
{
    public class User
    {
        public string AOUsername { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime CreationTime { get; set; }
        public int SizeChanges { get; set; }
        public int PositionChanges { get; set; }
        public TimeSpan MinTime { get; set; }
        public TimeSpan MaxTime { get; set; }
        public DateTime LastUpdateTime { get; set; }

        public User(string username)
        {
            AOUsername = username;
            CreationDate = DateTime.Now;
            CreationTime = DateTime.Now;
            SizeChanges = 0;
            PositionChanges = 0;
            MinTime = TimeSpan.MaxValue;
            MaxTime = TimeSpan.Zero;
            LastUpdateTime = DateTime.Now;
        }
    }
}
