﻿using System;
using System.Web.UI;

namespace WebApplication2
{
    public partial class Ostrzyzek2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Pobieranie URL obrazu 
                string OA_imageUrl = Request.QueryString["imageUrl"];
                int OA_index = int.TryParse(Request.QueryString["index"], out var parsedIndex) ? parsedIndex : -1;

                // Ustawianie źródła obrazu
                OA_DisplayedImage.ImageUrl = OA_imageUrl;
                OA_DisplayedImage.ToolTip = "Naciśnij lewy klawisz myszy aby powrócić do strony głównej";

                // Aktualizacja nagłówka
                OA_ImageHeader.Text = $"Wybrałeś obrazek numer: {OA_index + 1}";

                // Zapisywanie indeksu w ViewState
                ViewState["imageIndex"] = OA_index;
            }

            // Przypisywanie zdarzenia kliknięcia obrazu
            OA_DisplayedImage.Click += new ImageClickEventHandler(DisplayedImage_Click);
        }

        protected void DisplayedImage_Click(object sender, ImageClickEventArgs e)
        {
            // Przekieruj z powrotem do strony głównej z aktualnym indeksem obrazu
            int OA_index = (int)(ViewState["imageIndex"] ?? 0);
            Response.Redirect($"ListaObrazow.aspx?index={OA_index}");
        }
    }
}
