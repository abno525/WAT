﻿using System;
using System.Web.UI;

namespace WebApplication2
{
    public partial class Ostrzyzek1 : System.Web.UI.Page, IPostBackEventHandler
    {
        private static readonly string[] OA_images = { "/Images/img1.jpg", "/Images/img2.jpg", "/Images/img3.jpg", "/Images/img4.jpg", "/Images/img5.jpg" };

        // Właściwość do przechowywania indeksu obrazu
        protected int OA_index
        {
            get { return (int)(ViewState["index"] ?? 0); }
            set { ViewState["index"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Przyjmowanie przekazania indeksu obrazu
                string OA_indexParam = Request.QueryString["index"];
                if (int.TryParse(OA_indexParam, out var passedIndex) && passedIndex >= 0 && passedIndex < OA_images.Length)
                {
                    OA_index = passedIndex;
                }

                OA_Image.ImageUrl = OA_images[OA_index];
                UpdateCounter();
                UpdateButtons();
            }

            OA_ButtonLeft.Attributes.Add("onmouseleave", Page.ClientScript.GetPostBackEventReference(this, "Left"));
            OA_ButtonRight.Attributes.Add("onmouseleave", Page.ClientScript.GetPostBackEventReference(this, "Right"));
        }

        public void RaisePostBackEvent(string eventArgument)
        {
            switch (eventArgument)
            {
                case "Left":
                    CycleImageLeft();
                    break;
                case "Right":
                    CycleImageRight();
                    break;
            }
        }

        // Funkcja do przełączania obrazu w lewo
        private void CycleImageLeft()
        {
            if (OA_index > 0)
            {
                OA_index--;
                OA_Image.ImageUrl = OA_images[OA_index];
                UpdateCounter();
                UpdateButtons();
            }
        }

        // Funkcja do przełączania obrazu w prawo
        private void CycleImageRight()
        {
            if (OA_index < OA_images.Length - 1)
            {
                OA_index++;
                OA_Image.ImageUrl = OA_images[OA_index];
                UpdateCounter();
                UpdateButtons();
            }
        }

        // Funkcja do aktualizacji stanu przycisków
        private void UpdateButtons()
        {
            OA_ButtonLeft.Enabled = OA_index > 0; 
            OA_ButtonRight.Enabled = OA_index < OA_images.Length - 1; 
        }

        // Funkcja do aktualizacji licznika obrazów
        private void UpdateCounter()
        {
            OA_ImageCounter.Text = (OA_index + 1).ToString(); // Wyświetl numer aktualnego obrazu
        }

        // Zdarzenie kliknięcia obrazu
        protected void Image1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect($"PokazObrazu.aspx?imageUrl={OA_images[OA_index]}&index={OA_index}");
        }
    }
}
