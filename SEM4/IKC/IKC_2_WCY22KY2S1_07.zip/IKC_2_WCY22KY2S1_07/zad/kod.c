#include <REGX52.H>
#define Baud_rate 0xFD

void wait(void) {
  unsigned char x, y;
  for (x = 0; x < 200; x++) {
    for (y = 0; y < 100; y++) {
      ;
    }
  }
}

void Init(void) {
  P1 = 0xFF;  // do sygnalizacji
  P3 = 0x03;  // do transmisji szeregowej 0000 0011
}

void SerialInit(void) {
  TMOD = 0x20;  // Timer 1 tryb MODE 2 - AUTO RELOAD dla szybkosci transmisji
	SCON = 0x50;  // SERIAL MODE 1, 8-DATA BIT 1-START BIT, 1-STOP BIT, REN ENABLED
  TH1 = TL1 = Baud_rate;  // zainicjuj licznik
  TR1 = 1;  // odliczaj
}

void SendByte(unsigned char znak1) {
  TI = 0;
  SBUF = znak1;

  while (TI == 0);  // czekaj na zakonczenie transmisji

  TI = 0;  // wyczysc flage
}

void main() {
	
  Init();
  SerialInit();

  EA = 1;
  ES = 1;
	
	wait();
	
	 SendByte('.');
	 SendByte('.');
	 SendByte('.');
	 SendByte('.');

	 wait();
	 SendByte('b');
	
  while (1) {
		
		// 55
		SendByte('U');
		P1 = 'U';
		wait();
		
		// 4f
    SendByte('O');
    P1 = 'O';
    wait();
		
		//2f
		SendByte('/');
		P1 = '/';
		wait();
  }
}