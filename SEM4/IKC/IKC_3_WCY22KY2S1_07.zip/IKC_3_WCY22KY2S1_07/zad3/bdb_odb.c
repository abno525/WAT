#include <REGX52.H>
#define Baud_rate 0xFD

void wait(void) {
  unsigned char x, y;
  for (x = 0; x < 75; x++) {
    for (y = 0; y < 75; y++) {
      ;
    }
  }
}

void main() {
	
	P0_1 = 0;

	while (1) {
		
		P1 = 0xFF;
		
		if (P3_2 != P0_1) {
			P0_1 = !P0_1;
		}
			
		if (P0_4 == 0) {
			P1 = 0xAF;
			P0_1 = 1;
			wait();
			wait();
			wait();
			
			//P1 = P2;
			P1 = (0x00 & ~0x0F) | (P2 & 0x0F);
			wait();
			
			P0_1 = 0;
			P0_5 = 0;
			wait();
			wait();
			
			P0_5 = 1;
			wait();
			P1 = 0xFF;
		}
  }
}