#include <REGX52.H>
#define Baud_rate 0xFD


void wait(void) {
  unsigned char x, y;
  for (x = 0; x < 75; x++) {
    for (y = 0; y < 75; y++) {
      ;
    }
  }
}

void main() {
	
	int numer[5] = {8,3,7,4,4};
	int x;
	
	while (1) {
		
		P1 = 0xFF;
		P2 = 0xFF;
		P0_6 = 1;
		
		if (P3_2 == 0) {
			
			int i = 0;
			while ( i < 5) {
				
				x = numer[i];
					
				// P1 = 0x14
				P1 = (0x10 & ~0x0F) | (x & 0x0F);
				//P1 = P1 | 0x10;

				
				// P2 = 0x04;
				P2 = (0 & ~0x0F) | (x & 0x0F);
				wait();
				wait();
				
				while(P0_1 == 1) {
					wait();
				}
				
				P1 = (0x10 & ~0x0F) | (x & 0x0F);
				wait();
				
				P0_6 = 0;
				// P1 = 0x04;
				P1 = (0 & ~0x0F) | (x & 0x0F);
				wait();
				
				// P1 = 0x14;
				P1 = (0x10 & ~0x0F) | (x & 0x0F);
				wait();
				
				P0_6 = 1;
				
				while(P0_7 == 1) {
					wait();
				}
				
				while(P0_7 == 0) {
					// P1 = 0x14;
					//P1 = (0 & ~0x0F) | (x & 0x0F);
					wait();
				}
				
				wait();
				i++;
				P2 = 0xFF;
			}
		}
  }
}