#include <REGX52.H>

#define Jeden 0xE7
#define Dwa 0xEB
#define Trzy 0xED
#define Cztery 0xD7
#define Piec 0xDB
#define Szesc 0xDD
#define Siedem 0xB7
#define Osiem 0xBB
#define Dziewiec 0xBD
#define Zero 0x7B
#define Gwiazdka 0x77
#define Hash 0x7D

#define Dioda P0_0

#define Zapal 0
#define Zgas 1
#define Warunek (Key_3&Key_2&Key_1)==0

unsigned char code Tab[] = { 0x7F, 0xBF, 0xDF, 0xEF
};

unsigned char bdata Key;
sbit Key_3 = Key ^ 3;
sbit Key_2 = Key ^ 2;
sbit Key_1 = Key ^ 1;

void wait(void)
{
	unsigned char data x, y;
	for (x = 0; x < 20; x++)
	{
		for (y = 0; y < 100; y++)
		{;
		}
	}
}

void main(void)
{
	unsigned char data index = 0;
	// flaga, zabezpieczająca przed wielokrotnym wejściem do procedury wykonawczej przy przytrzymaniu klawisza
	bit Zezwalaj = 1;

	for (;;)
	{
		P2 = Tab[index];
		Key = P2;
		if (Warunek)
		{
			if (Zezwalaj == 1)
			{
				
				switch(Key) {
					case Zero 	: P1_5 = 0;
												P1_4 = 0;
												P1_7 = 0;
												
												P1_0 = 0;
												P1_1 = 0;
												P1_2 = 0;
												break;
					
					case Jeden 	:	P1_5 = 0;
												P1_4 = 0;
												P1_7 = 0;
												
												P1_1 = 0;
												P1_2 = 0;
												break;
					
					case Dwa 	:		P1_5 = 0;
												P1_7 = 0;
													
												P1_0 = 0;
												P1_1 = 0;
												P1_2 = 0;
												P1_3 = 0;
												break;
												
					case Trzy :		P1_5 = 0;
												P1_7 = 0;
												
												P1_1 = 0;
												P1_2 = 0;
												P1_3 = 0;
												break;
												
					case Cztery :	P1_5 = 0;
												P1_7 = 0;
												
												P1_0 = 0;
												P1_2 = 0;
												P1_3 = 0;
												break;
												
					case Piec 	: P1_5 = 0;
												P1_7 = 0;
												
												P1_2 = 0;
												P1_3 = 0;
												break;
												
					case Szesc :	P1_5 = 0;
												P1_7 = 0;
												
												P1_0 = 0;
												P1_1 = 0;
												P1_3 = 0;
												break;
												
					case Siedem :	P1_5 = 0;
												P1_7 = 0;
													
												P1_3 = 0;
												P1_1 = 0;
												break;
												
					case Osiem :	P1_5 = 0;
												P1_7 = 0;
												
												P1_0 = 0;
												P1_3 = 0;
												break;
												
					case Gwiazdka :	P1_5 = 0;
												P1_4 = 0;
												P1_7 = 0;
												
												P1_3 = 0;
												P1_2 = 0;
												P1_0 = 0;
												break;
												
					case Hash :	P1_6 = 0;
												P1_7 = 0;
												
												P1_1 = 0;
												P1_3 = 0;
												break;
												
					case Dziewiec :	P1_5 = 0;
												P1_7 = 0;
												
												
												P1_3 = 0;
												break;
				}
				
				wait();
				wait();
				wait();
				wait();
				wait();
				// Zablokuj wejście do procedur obsługi klawiszy
				Zezwalaj = 0;
			}
		}
		else
		{
			if (index < 3)
			{
				index++;
			}
			else
			{
				index = 0;
			}
			
			P1_0 = 1;
			P1_1 = 1;
			P1_2 = 1;
			P1_3 = 1;
			P1_4 = 1;
			P1_5 = 1;
			P1_6 = 1;
			P1_7 = 1;

			// odblokowanie zezwalania na wejście do procedur obsługi klawiszy 
			Zezwalaj = 1;
		}
	}
}